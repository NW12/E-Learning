<br/>
<p align="center">
<img src="https://i.imgur.com/bYwl7Vf.png" alt="Learn Regex">
</p><br/>

## Çeviriler:

* [English](README.md)
* [Español](README-es.md)
* [Français](README-fr.md)
* [中文版](README-cn.md)
* [日本語](README-ja.md)
* [한국어](README-ko.md)
* [Turkish](README-tr.md)
* [Greek](README-gr.md)
* [Polish](README-pl.md)

## Düzenli İfade Nedir?

> Düzenli ifade, bir metinden belirli bir deseni bulmak için kullanılan bir karakter veya sembol grubudur.

Bir düzenli ifade soldan sağa söz konusu harf öbekleriyle eşleşen bir desendir. "Regular expression" söylemesi zor bir tabirdir, genellikle "regex" ya da "regexp" olarak kısaltılmış terimler olarak bulacaksınız. Düzenli ifade bir harf öbeğinde ki bir metin değiştirmek, form doğrulamak, bir desen eşleşmesine dayalı harf öbeğinden bir alt harf öbeği ayıklamak ve çok daha fazlası için kullanılır.

Bir uygulama yazdığınızı hayal edin ve bir kullanıcı kullanıcı adını seçtiğinde kullanıcı adı için kurallar belirlemek istiyorsunuz. Kullanıcı adının harfler, sayılar, altçizgiler ve tireler içermesine izin vermek istiyoruz. Ayrıca, Kullanıcı adındaki karakter sayısını sınırlamak istiyoruz böylece çirkin görünmeyecek. Bir kullanıcı adını doğrulamak için aşağıdaki düzenli ifadeyi kullanıyoruz:

<br/><br/>
<p align="center">
  <img src="./img/regexp-tr.png" alt="Regular expression">
</p>

Yukardaki düzenli ifade `john_doe`, `jo-hn_doe` ve `john12_as` gibi girişleri kabul edebilir.
`Jo` girişi uyuşmaz, çünkü harf öbeği büyük harf içeriyor ve aynı zamanda uzunluğu 3 karakterden az.

## İçindekiler

- [Temel Eşleştiriciler](#1-temel-eşleştiriciler)
- [Meta Karakterler](#2-meta-karakterler)
  - [Nokta](#21-nokta)
  - [Karakter takımı](#22-karakter-takımı)
    - [Negatiflenmiş karakter seti](#221-negatiflenmiş-karakter-seti)
  - [Tekrarlar](#23-tekrarlar)
    - [Yıldız İşareti](#231-yıldız-İşareti)
    - [Artı İşareti](#232-artı-İşareti)
    - [Soru İşareti](#233-soru-İşareti)
  - [Süslü Parantez](#24-süslü-parantez)
  - [Karakter Grubu](#25-karakter-grubu)
  - [Değişim](#26-değişim)
  - [Özel Karakter Hariç Tutma](#27-Özel-karakter-hariç-tutma)
  - [Sabitleyiciler](#28-sabitleyiciler)
    - [Ters v işareti](#281-Şapka-İşareti)
    - [Dolar işareti](#282-dolar-İşareti)
- [Kısaltma Karakter Takımları](#3-kısaltma-karakter-takımları)
- [Bakınmak](#4-bakınmak)
  - [Olumlu Bakınma](#41-positive-lookahead)
  - [Olumsuz Bakınma](#42-negative-lookahead)
  - [Positive Lookbehind](#43-positive-lookbehind)
  - [Negative Lookbehind](#44-negative-lookbehind)
- [İşaretler](#5-İşaretler)
  - [Büyük/Küçük harf duyarlılığı](#51-büyükküçük-harf-duyarlılığı)
  - [Bütünsel Arama](#52-genel-arama)
  - [Çok satırlı](#53-Çok-satırlı)

## 1. Temel Eşleştiriciler

Bir düzenli ifade bir metin içinde arama yapabilmek için kullandığımız bir karakter desenidir.
Örneğin, `the` düzenli ifadesi şu anlama gelir: `t` harfi ardından `h`, ardından `e` harfi gelir.

<pre>
"the" => The fat cat sat on <a href="#learn-regex"><strong>the</strong></a> mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/dmRygT/1)

`123` düzenli ifadesi `123` harf öbeğiyle eşleşir. Düzenli ifade birbiri ardına, girilen harf öbeğindeki her karakter düzenli ifadenin içindeki her karakterle karşılaştırılarak eşleştirilir. Düzenli ifadeler normal olarak büyük/küçük harfe duyarlıdırlar, yani `The` düzenli ifadesi `the` harf öbeğiyle eşleşmez.

<pre>
"The" => <a href="#learn-regex"><strong>The</strong></a> fat cat sat on the mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/1paXsy/1)

## 2. Meta Karakterler

Meta karakterler düzenli ifadelerin yapı taşlarıdırlar. Meta karakterler kendileri için değil bunun yerine bazı özel yollarla yorumlanırlar. Bazı meta karakterler özel anlamları vardır ve bunlar köşeli parantez içinde yazılırlar.

Meta karakterler aşağıdaki gibidir:

|Meta karakter|Açıklama|
|:----:|----|
|.|Satır sonuc hariç herhangi bir karakterle eşleşir.|
|[ ]|Köşeli parantezler arasında bulunan herhangi bir karakterle eşleşir.|
|[^ ]|Köşeli parantez içerisinde yer alan `^` işaretinden sonra girilen karakterler haricindeki karakterlerle eşleşir.|
|*|Kendisinden önce yazılan karakterin sıfır veya daha fazla tekrarı ile eşleşir.|
|+|Kendisinden önce yazılan karakterin bir veya daha fazla tekrarı ile eşleşir.|
|?|Kendisinden önce yazılan karakterin varlık durumunu opsiyonel kılar.|
|{n,m}|Kendisinden önce yazılan karakterin en az `n` en fazla `m` değeri kadar olmasını ifade eder.|
|(xyz)|Verilen sırayla `xyz` karakterleriyle eşleşir.|
|&#124;|`|` karakterinden önce veya sonra verilen ifadelerin herhangi biriyle eşleşir. Or anlamı verir.|
|&#92;|Sonraki karakteri kaçırır. Bu, ayrılmış karakterleri eşleştirmenizi sağlar <code>[ ] ( ) { } . * + ? ^ $ \ &#124;</code>|
|^|Girilen verinin başlangıcını ifade eder.|
|$|Girilen veririnin sonunu ifade eder.|

## 2.1 Nokta

Nokta `.` meta karakterin en basit örneğidir. `.` meta karakteri satır başlangıcı hariç herhangi bir karakterle eşleşir.
Örneğin, `.ar` düzenli ifadesinin anlamı: herhangi bir karakterin ardından `a` harfi ve `r` harfi gelir.

<pre>
".ar" => The <a href="#learn-regex"><strong>car</strong></a> <a href="#learn-regex"><strong>par</strong></a>ked in the <a href="#learn-regex"><strong>gar</strong></a>age.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/xc9GkU/1)

## 2.2 Karakter Takımı

Karakter takımları aryıca Karakter sınıfı olarak bilinir. Karakter takımlarını belirtmek için köşeli ayraçlar kullanılır.
Karakterin aralığını belirtmek için bir karakter takımında tire kullanın. Köşeli parantezlerdeki karakter aralığının sıralaması önemli değildir. 

Örneğin, `[Tt]he` düzenli ifadesinin anlamı: bir büyük `T` veya küçük `t` harflerinin ardından sırasıyla `h` ve `e` harfi gelir.

<pre>
"[Tt]he" => <a href="#learn-regex"><strong>The</strong></a> car parked in <a href="#learn-regex"><strong>the</strong></a> garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/2ITLQ4/1)

Bununla birlikte, bir karakter takımı içerisindeki bir periyot bir tam periyot demektir.

`ar[.]` düzenli ifadesinin anlamı: Küçük `a` karakteri ardından `r` harfi gelir, ardından bir `.` karakteri gelir.

<pre>
"ar[.]" => A garage is a good place to park a c<a href="#learn-regex"><strong>ar.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/wL3xtE/1)

### 2.2.1 Negatiflenmiş karakter seti

Genellikle, şapka `^` sembolü harf öbeğinin başlangıcını temsil eder, ama köşeli parantez içinde kullanıldığında verilen karakter takımını hariç tutar.

Örneğin, `[^c]ar` ifadesinin anlamı: `c` harfinden hariç herhangi bir harfin ardından `a`, ardından `r` gelir.

<pre>
"[^c]ar" => The car <a href="#learn-regex"><strong>par</strong></a>ked in the <a href="#learn-regex"><strong>gar</strong></a>age.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/nNNlq3/1)

## 2.3 Tekrarlar

`+`, `*` ya da `?` meta karakterlerinden sonra bir alt desenin kaç defa tekrar edebileceğini belirtmek için kullanılır. Bu meta karakterler farklı durumlarda farklı davranırlar.

### 2.3.1 Yıldız İşareti

`*` sembolü, kendinden önce girilen eşlemenin sıfır veya daha fazla tekrarıyla eşleşir. Ama bir karakter seti ya da sınıf sonrasına girildiğinde, tüm karakter setinin tekrarlarını bulur.

`a*` düzenli ifadesinin anlamı: `a` karakterinin sıfır veya daha fazla tekrarı. 
`[a-z]*` düzenli ifadesinin anlamı: bir satırdaki herhangi bir sayıdaki küçük harfler.

<pre>
"[a-z]*" => T<a href="#learn-regex"><strong>he</strong></a> <a href="#learn-regex"><strong>car</strong></a> <a href="#learn-regex"><strong>parked</strong></a> <a href="#learn-regex"><strong>in</strong></a> <a href="#learn-regex"><strong>the</strong></a> <a href="#learn-regex"><strong>garage</strong></a> #21.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/7m8me5/1)

`*` sembolü `.` meta karakteri ile `.*` karakterinin herhangi harf öbeğine eşleştirmek için kullanılabilir. `*` sembolü boşluk karakteriyle `\s` bir harf öbeğinde boşluk karakterlerini eşleştirmek için kullanılabilir.

Örneğin, `\s*cat\s*` düzenli ifadesinin anlamı: sıfır veya daha fazla boşluk ardından küçük `c` karakteri gelir, ardından küçük `a` karakteri gelir, ardından küçük `t` karakteri gelir, ardından sıfır veya daha fazla boşluk gelir.

<pre>
"\s*cat\s*" => The fat<a href="#learn-regex"><strong> cat </strong></a>sat on the <a href="#learn-regex">con<strong>cat</strong>enation</a>.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/gGrwuz/1)

### 2.3.2 Artı İşareti

`+` sembolü, kendinden önce girilen eşlemenin bir veya daha fazla tekrarıyla eşleşir.

Örneğin, `c.+t` ifadesinin anlamı: küçük `c` harfi, ardından en az bir karakter gelir, ardından küçük `t` karakteri gelir.
Örnekte açıklamak gereken önemli nokta: `t` harfi cümledeki son `t` harfi olacaktır. `c` ve `t` harfi arasında en az bir karakter vardır.

<pre>
"c.+t" => The fat <a href="#learn-regex"><strong>cat sat on the mat</strong></a>.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/Dzf9Aa/1)

### 2.3.3 Soru İşareti

Düzenli ifadelerde `?` meta karakterinden önce girilen karakteri opsiyonel olarak tanımlar. Bu sembol önce gelen karakterin sıfır veya bir örbeğiyle eşleşir.

Örneğin, `[T]?he` ifadesinin anlamı: opsiyonel büyük `T` harfi, ardından küçük `h` karakteri gelir, ardından küçük `e` karakteri gelir.

<pre>
"[T]he" => <a href="#learn-regex"><strong>The</strong></a> car is parked in the garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/cIg9zm/1)

<pre>
"[T]?he" => <a href="#learn-regex"><strong>The</strong></a> car is parked in t<a href="#learn-regex"><strong>he</strong></a> garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/kPpO2x/1)

## 2.4 Süslü Parantez

Düzenli ifadelerde miktar belirliyiciler olarakda bilinen süslü parantezler, bir karakterin veya karakter grubunun kaç defa tekrar edebileceğini belirtmek için kullanılırlar.

Örneğin, `[0-9]{2,3}` ifadesinin anlamı: 0 ile 0 aralığındaki karakterlerden, en az 2 en fazla 3 defa ile eşleş.

<pre>
"[0-9]{2,3}" => The number was 9.<a href="#learn-regex"><strong>999</strong></a>7 but we rounded it off to <a href="#learn-regex"><strong>10</strong></a>.0.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/juM86s/1)

İkinci numarayı boş bırakabiliriz.

Örneğin, `[0-9]{2,}` ifadesinin anlamı: En az 2 veya daha fazla defa eşleş.
Düzenli ifadeden virgülü kaldırırsak `[0-9]{3}`: doğrudan 3 defa eşleşir.

<pre>
"[0-9]{2,}" => The number was 9.<a href="#learn-regex"><strong>9997</strong></a> but we rounded it off to <a href="#learn-regex"><strong>10</strong></a>.0.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/Gdy4w5/1)

<pre>
"[0-9]{3}" => The number was 9.<a href="#learn-regex"><strong>999</strong></a>7 but we rounded it off to 10.0.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/Sivu30/1)

## 2.5 Karakter Grubu

Karakter grubu parantezler içine yazılmış alt desenler grubudur. Daha önce tasarım deseninde değindiğimiz gibi, bir karakterden önce bir miktar belirleyici koyarsak önceki karakteri tekrar eder. Fakat miktar belirleyiciyi bir karakter grubundan sonra koyarsak tüm karakter grubunu tekrarlar.

Örneğin: `(ab)*` düzenli ifadesi "ab" karakterinin sıfır veya daha fazla tekrarıyla eşleşir.

Ayrıca karakter grubu içinde `|` meta karakterini kullanabiliriz.

Örneğin, `(c|g|p)ar` düzenli ifadesinin anlamı: küçük `c`, `g` veya `p` karakteri, ardından `a` karakteri, ardından `r` karakteri gelir.

<pre>
"(c|g|p)ar" => The <a href="#learn-regex"><strong>car</strong></a> is <a href="#learn-regex"><strong>par</strong></a>ked in the <a href="#learn-regex"><strong>gar</strong></a>age.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/tUxrBG/1)

## 2.6 Değişim

Düzenli ifadede dik çizgi alternasyon(değişim, dönüşüm) tanımlamak için kullanılır. Alternasyon birden fazla ifade arasındaki bir koşul gibidir. Şu an, karakter grubu ve alternasyonun aynı şekilde çalıştığını düşünüyor olabilirsiniz. Ama, Karakter grubu ve alternasyon arasındaki büyük fark karakter grubu karakter düzeyinde çalışır ama alternasyon ifade düzeyinde çalışır. 

Örneğin, `(T|t)he|car` düzenli ifadesinin anlamı: Büyük `T` ya da küçük `t` karakteri, ardından küçük `h` karakteri, ardından küçük `e` ya da `c` karakteri, ardından küçük `a`, ardından küçük `r` karakteri gelir.

<pre>
"(T|t)he|car" => <a href="#learn-regex"><strong>The</strong></a> <a href="#learn-regex"><strong>car</strong></a> is parked in <a href="#learn-regex"><strong>the</strong></a> garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/fBXyX0/1)

## 2.7 Özel Karakter Hariç Tutma

`\` işareti sonraki karakteri hariç tutmak için kullanılır. Bu bir semboülü ayrılmış karakterlerde `{ } [ ] / \ + * . $ ^ | ?` dahil olmak üzere eşleşen bir karakter olarak belirtmemizi sağlar. Bir özel karakteri eşleşen bir karakter olarak kullanmak için önüne `\` işareti getirin.

Örneğin, `.` düzenli ifadesi yeni satır hariç herhangi bir karakteri eşleştirmek için kullanılır. 
Bir harf öbeği içinde nokta `.` karakterini yakalamak için `.` ayrılmış karakterini hariç tutmamız gerekir. Bunun için nokta önüne `\` işaretini koymamız gereklidir.

`(f|c|m)at\.?` düzenli ifadesinin anlamı: küçük `f`, `c`ya da `m` harfi, ardından küçük `a` harfi, ardından küçük `t` harfi, ardından opsiyonel `.` karakteri gelir.

<pre>
"(f|c|m)at\.?" => The <a href="#learn-regex"><strong>fat</strong></a> <a href="#learn-regex"><strong>cat</strong></a> sat on the <a href="#learn-regex"><strong>mat.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/DOc5Nu/1)

## 2.8 Sabitleyiciler

Düzenli ifadelerde, eşleşen sembolün girilen harf öbeğinin başlangıç sembolü veya bitiş sembolü olup olmadığını kontrol etmek için sabitleyicileri kullanırız. 
Sabitleyiciler iki çeşittir: İlk çeşit eşleşen karakterin girişin ilk karakteri olup olmadığını kontrol eden şapka `^` karakteri, ve ikinci çeşit eşleşen karakterin girişin son karakteri olup olmadığını kontrol eden dolar `$` karakteridir.

### 2.8.1 Şapka İşareti

Şapka `^` işareti eşleşen karakterin giriş harf öbeğinin ilk karakteri olup olmadığını kontrol etmek için kullanılır.
Eğer `^a` düzenli ifadesini `abc` harf öbeğine uygularsak `a` ile eşleşir. Ama `^b` ifadesini uygularsak bir eşleşme bulamayız. Bunun nedeni `abc` harf öbeğinde `b` karakterinin başlangıç karakteri olmamasıdır.

Bir başka örnek üzerinden ilerlersek, 

`^(T|t)he` düzenli ifadesinin anlamı: büyük `T` ya da `t` karakteri giriş harf öbeğinin ilk karakteri olmak üzere, ardından küçük `h`, ardından küçük `e` karakteri gelir.

<pre>
"(T|t)he" => <a href="#learn-regex"><strong>The</strong></a> car is parked in <a href="#learn-regex"><strong>the</strong></a> garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/5ljjgB/1)

<pre>
"^(T|t)he" => <a href="#learn-regex"><strong>The</strong></a> car is parked in the garage.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/jXrKne/1)

### 2.8.2 Dolar İşareti

Dolar `$` işareti eşleşen karakterin giriş harf öbeğinin son karakteri olup olmadığını kontrol etmek için kullanılır.

Örneğin, `(at\.)$` ifadesinin anlamı: küçük bir `a` karakteri, ardından küçük bir `t` karakteri, ardıdan nokta `.` karakteri gelir ve bu eşleşme harf öbeğinin sonunda olmalıdır.

<pre>
"(at\.)" => The fat c<a href="#learn-regex"><strong>at.</strong></a> s<a href="#learn-regex"><strong>at.</strong></a> on the m<a href="#learn-regex"><strong>at.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/y4Au4D/1)

<pre>
"(at\.)$" => The fat cat. sat. on the m<a href="#learn-regex"><strong>at.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/t0AkOd/1)

##  3. Kısaltma Karakter Takımları

Regex, yaygın olarak kullanılan düzenli ifadeler için uygun kısaltmalar sunan sık kullanılan karakter setleri için kısaltmalar sağlar.

Kullanılan karakter setleri kısaltmaları aşağıdaki gibidir:

|Kısaltma|Açıklama|
|:----:|----|
|.|Satır başı hariç herhangi bir karakter|
|\w|Alfanumerik karakterlerle eşleşir: `[a-zA-Z0-9_]`|
|\W|Alfanumerik olmayan karakterlerle eşleşir: `[^\w]`|
|\d|Rakamlarla eşlelir: `[0-9]`|
|\D|Rakam olmayan karakterlerle eşleşir: `[^\d]`|
|\s|Boşluk karakteri ile eşleşir: `[\t\n\f\r\p{Z}]`|
|\S|Boşluk karakteri olmayan karakterlerle eşleşir: `[^\s]`|

## 4. Bakınmak

Bakınma sembolleri, bir ifade öncesinde veya sonrasında başka bir ifademiz olduğunda kullanılırlar.

Örneğin, `$4.44 ve $10.88` girişlerinden `$` karakteri önündeki tüm sayıları almak istiyoruz, bu durumda `(?<=\$)[0-9\.]*` ifadesini kullanırız.

`(?<=\$)[0-9\.]*` ifadesinin anlamı: `.` karakterini içeren ve `$` karakteriyle devam eden tüm sayıları al.

Düzenli ifadelerde kullanılan bakınma sembolleri aşağıdadır:

|Sembol|Açıklama|
|:----:|----|
|?=|Positive Lookahead (Verdiğimiz ifade sonrası arar ve `eşleşme varsa` sonuç döndürür.)|
|?!|Negative Lookahead (Verdiğimiz ifade sonrası arar ve `eşleşme yoksa` sonuç döndürür.)|
|?<=|Positive Lookbehind (Verdiğimiz ifade öncesini arar ve `eşleşme varsa` sonuç döndürür.)|
|?<-!-|Negative Lookbehind Verdiğimiz ifade öncesini arar ve `eşleşme yoksa` sonuç döndürür.|

### 4.1 Positive Lookahead

Positive Lookahead, ifadenin ilk bölümü bakınma ifadesiyle devam etmesi gerektiğini savunur. Bulunan eşleşme yalnızca ifadenin ilk bölümüyle eşleşen metin içerir. Olumlu bir bakınma tanımlamak için, içinde eşittir işareti yer alan parantezler `(?=...)` şeklinde kullanılır. Bakınma ifadesi parantezler içinde eşittir işaretinden sonra yazılır.

Örneğin, `[T|t]he(?=\sfat)` ifadesinin anlamı: opsiyonel küçük bir `t` ya da büyük `T` harfi, ardından `h` harfi gelir, ardından `e` harfi gelir. Parantez içinde ise bu dizilimin bir boşluk karakterinden sonra `fat` öbeğiyle devam edeceğini tanımlıyoruz.

<pre>
"[T|t]he(?=\sfat)" => <a href="#learn-regex"><strong>The</strong></a> fat cat sat on the mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/IDDARt/1)

### 4.2 Negative Lookahead

Negative Lookahead sembolü positive lookahead tersine, verdiğimiz desenle devam etmemesi durumunda eşleşir. Bu sembol positive lookahead gibi tanımlanır ama `=` işareti yerine `!` kullanılır.

`[T|t]he(?!\sfat)` ifadesinin anlamı: opsiyonel küçük bir `t` ya da büyük `T` harfi, ardından `h` harfi gelir, ardından `e` harfi gelir, ardından öncesinde boşluk olan bir `fat` öbeği olmamalıdır.


<pre>
"[T|t]he(?!\sfat)" => The fat cat sat on <a href="#learn-regex"><strong>the</strong></a> mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/V32Npg/1)

### 4.3 Positive Lookbehind

Positive Lookbehind, belirli bir desenden önceki eşleşmeleri almak için kullanılır. `(?<=...)` ile gösterilir.

Örneğin, `(?<=[T|t]he\s)(fat|mat)` ifadesinin anlamı: Öncesinde `The` veya `the` öbekleri olan tüm `fat` veya `mat` öbeklerini getir.

<pre>
"(?<=[T|t]he\s)(fat|mat)" => The <a href="#learn-regex"><strong>fat</strong></a> cat sat on the <a href="#learn-regex"><strong>mat</strong></a>.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/avH165/1)

### 4.4 Negative Lookbehind

Negative Lookbehind, belirli bir desenden önce olmayan eşleşmeleri almak için kullanılır. `(?<=!..)` ile gösterilir.

Örneğin, `(?<!(T|t)he\s)(cat)` ifadesinin anlamı: Öncesinde `The` veya `the` öbekleri yer almayan tüm `cat` öbeklerini getir.

<pre>
"(?&lt;![T|t]he\s)(cat)" => The cat sat on <a href="#learn-regex"><strong>cat</strong></a>.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/8Efx5G/1)

## 5. İşaretler

İşaretler ayrıca düzenleyiciler olarak bilinirler, çünkü onlar bir düzenli ifadenin çıktısını düzenlerler. Bu işaretler herhangi bir sırada veya kombinasyonda kullanılabilirler, ve bunlar Düzenli İfadelerin ayrılmaz bir parçasıdırlar.

|İşaret|Açıklama|
|:----:|----|
|i|Büyük küçük harf duyarlılık: Eşleştirmeleri küçük/büyük harfe karşı duyarsız yapar.|
|g|Genel Arama: Girilen harf öbeği boyunca bir desen arar.|
|m|Çok satırlı: Sabitleyici meta karakteri her satırda çalışır.|

### 5.1 Büyük/Küçük harf duyarlılığı

`ì` işaretleyicisi büyük/küçük harfe duyarsız eşleştirme yapmak için kullanılır.

Örneğin, `/The/gi` ifadesi: büyük `T` harfi, ardından küçük `h` harfi, ardından küçük `e` harfi gelir. ifadenin sonunda yer alan `i` işareti büyük-küçük harfe karşı duyarsız olması gerektiğini belirtir. Ayrıca `g` işaretinide kullandığımızı görebilirsiniz, tüm text içinde bu aramayı yapmak istediğimiz için `g` işaretini ayrıca belirtiyoruz.

<pre>
"The" => <a href="#learn-regex"><strong>The</strong></a> fat cat sat on the mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/dpQyf9/1)

<pre>
"/The/gi" => <a href="#learn-regex"><strong>The</strong></a> fat cat sat on <a href="#learn-regex"><strong>the</strong></a> mat.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/ahfiuh/1)

### 5.2 Genel Arama

`g` işareti bir giriş içinde eşleşen tüm varsayonları bulmak için kullanılır. `g` işareti kullanılmazsa ilk eşleşme bulunduktan sonra arama sona erer.

<pre>
"/.(at)/" => The <a href="#learn-regex"><strong>fat</strong></a> cat sat on the mat.
</pre>

[Test the regular expression](https://regex101.com/r/jnk6gM/1)

<pre>
"/.(at)/g" => The <a href="#learn-regex"><strong>fat</strong></a> <a href="#learn-regex"><strong>cat</strong></a> <a href="#learn-regex"><strong>sat</strong></a> on the <a href="#learn-regex"><strong>mat</strong></a>.
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/dO1nef/1)

### 5.3 Çok Satırlı

`m` işareti çok satırlı bir eşleşme sağlamak için kullanılır. Daha önce sabitleyicilerde gördüğümüz gibi `(^, $)` sembolleri aradığımız desenin harf öbeğinin başında veya sonunda olup olmadığını kontrol etmemiz için kullanılır. Bu sabitleyicilerin tüm satırlarda çalışması için `m` işaretini kullanırız.

Örneğin, `/at(.)?$/gm` ifadesinin anlamı: küçük `a` harfi, ardından küçük `t` harfi gelir, ardından opsiyonel olarak yeni satır hariç herhangi birşey gelebilir. `m` işaretini kullandığımız için bir girişin her satırının sonunda eşleştirir.

<pre>
"/.at(.)?$/" => The fat
                cat sat
                on the <a href="#learn-regex"><strong>mat.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/hoGMkP/1)

<pre>
"/.at(.)?$/gm" => The <a href="#learn-regex"><strong>fat</strong></a>
                  cat <a href="#learn-regex"><strong>sat</strong></a>
                  on the <a href="#learn-regex"><strong>mat.</strong></a>
</pre>

[Düzenli ifadeyi test edin](https://regex101.com/r/E88WE2/1)

## Contribution

* Report issues
* Open pull request with improvements
* Spread the word
* Reach out to me directly at ziishaned@gmail.com or [![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/ziishaned.svg?style=social&label=Follow%20%40ziishaned)](https://twitter.com/ziishaned)

## License

MIT © [Zeeshan Ahmed](mailto:ziishaned@gmail.com)
